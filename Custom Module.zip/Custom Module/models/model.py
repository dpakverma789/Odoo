# TODO do not forget to update file in init of the model!

from odoo import api, exceptions, fields, models, _


class ClassName(models.Model):
    _name = "module.name"
    _inherit = ['module.name']
    _description = "module description"
    _rec_name = "name"
    _order = "name"

