{
    'name': 'Module Name',
    'version': '1.0',
    'summary': 'Module Summary',
    'sequence': 1,
    'description': """ """,
    'category': 'Extra Tools',
    'website': '',
    'images': [],
    'depends': ['base'],
    'data': [
        # security/file_name
        
        # views/file_name
       
        # wizard/file_name

        # data/file_name

        # demo data files
    ],
    'qweb': [
        # qweb templates
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
    'license': 'LGPL-3',
}
